<?php

//Buat class
class Matakuliah_model extends CI_Model{
    //Buat Struktur Data
    public $nama, $sks, $kode;

}

?>