<footer>
        <p>Creat by <a href="http://nurulfikri.ac.id">Pusinfo &copy;2017</a></p>
    </footer>
    
</body>
</html>